clear all
clc
currentFolder = pwd;
addpath(genpath(currentFolder))
% parameter setting
warning('off')
% 
format short
SE =  30; % 
Dim = 10;% 
Range = repmat([-5.12;5.12],1,Dim);% 
Iterations = 1e2*Dim;% maximum number of iterations
Best = Range(1,:) + (Range(2,:) - Range(1,:)).*rand(1,Dim);
% profile on

tic
[xmin,fxmin,history] = STA(@Rastrigin,Best,SE,Range,Iterations);
toc
xmin
fxmin
semilogy(history,'b-o')



