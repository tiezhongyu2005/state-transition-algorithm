function [Best,fBest,history]=STA(funfcn,Best,SE,Range,Iterations)
% parameters
alpha_max = 1;
alpha_min = 1e-4;
alpha = alpha_max;
beta = 1;
gamma = 1;
delta = 1;
fc = 2;
% initialization
history = zeros(Iterations,1);
fBest = feval(funfcn,Best);
% iterations
for iter = 1:Iterations
    if alpha < alpha_min
        alpha = alpha_max;
    end
    
    [Best,fBest] = expand(funfcn,Best,fBest,SE,Range,beta,gamma);

    
    [Best,fBest] = rotate(funfcn,Best,fBest,SE,Range,alpha,beta);

    
    [Best,fBest] = axesion(funfcn,Best,fBest,SE,Range,beta,delta);

    history(iter) = fBest;
    alpha = alpha/fc;
    fprintf('iter=%d      ObjVal=%g\n',iter,fBest);

end



