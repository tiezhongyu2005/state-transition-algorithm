function y=op_rotate(Best,SE,alpha)
%rotation
n = length(Best);
R1 = 2*rand(SE,n)-1;
R2 = 2*rand(SE,1)-1;
y = repmat(Best,SE,1) + alpha*repmat(R2,1,n).*R1./repmat(sqrt(sum(R1.*R1,2)),1,n);
