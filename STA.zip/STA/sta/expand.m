function [Best,fBest] = expand(funfcn,Best,fBest,SE,Range,beta,gamma)

Pop_Lb = repmat(Range(1,:),SE,1);
Pop_Ub = repmat(Range(2,:),SE,1);
oldBest = Best;
flag = 0;

State = op_expand(Best,SE,gamma); % expansion
%Apply  for State > Pop_Ub or State < Pop_Lb
changeRows = State > Pop_Ub;
State(find(changeRows)) = Pop_Ub(find(changeRows));
changeRows = State < Pop_Lb;
State(find(changeRows)) = Pop_Lb(find(changeRows));
%Apply  for State > Pop_Ub or State < Pop_Lb
[newBest,fGBest] = fitness(funfcn,State);
if fGBest < fBest
    fBest = fGBest;
    Best = newBest;
    flag = 1;
else
    flag = 0;  
end

if flag ==1
    State = op_translate(oldBest,Best,SE,beta);% translation
    %Apply  for State > Pop_Ub or State < Pop_Lb
    changeRows = State > Pop_Ub;
    State(find(changeRows)) = Pop_Ub(find(changeRows));
    changeRows = State < Pop_Lb;
    State(find(changeRows)) = Pop_Lb(find(changeRows));
    %Apply  for State > Pop_Ub or State < Pop_Lb
    [newBest,fGBest] = fitness(funfcn,State);
    if fGBest < fBest
        fBest = fGBest;
        Best = newBest;  
    end
end





